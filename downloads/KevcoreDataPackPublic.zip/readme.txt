Drag the folder above (or below) into your world's datapack folder

SOME PARTS OF THE CMDS DO NOT WORK AS SOME PARTS NEED OP PERMISSION LEVEL 3. 
IF YOUR RUNNING A SERVER AND USE THIS DATAPACK, SET YOUR FUNCTION-PERMISSION-LEVEL TO 3 IN SERVER.PROPERITES
OTHERWISE, ENJOY!

Here are the commands you can use to get the custom enchantments:

Auto Smelt: /give @p iron_pickaxe{display:{Lore:['[{"text":"Auto Smelt","italic":false,"color":"gray"}]']}} 1
Fire Bow I: /give @p bow{display:{Lore:['[{"text":"Fire maker","italic":false,"color":"gray"}]']}} 1
Fire Bow II: /give @p bow{display:{Lore:['[{"text":"Fire maker II","italic":false,"color":"gray"}]']}} 1
Ice Aspect I: /give @p iron_sword{display:{Lore:['[{"text":"Ice Aspect","italic":false,"color":"gray"}]']}} 1
Ice Aspect II: /give @p iron_sword{display:{Lore:['[{"text":"Ice Aspect II","italic":false,"color":"gray"}]']}} 1
Lava Walker I: /give @p iron_boots{display:{Lore:['[{"text":"Lava Walker","italic":false,"color":"gray"}]']}} 1
Lava Walker II: /give @p iron_boots{display:{Lore:['[{"text":"Lava Walker II","italic":false,"color":"gray"}]']}} 1
Lava Walker III: /give @p iron_boots{display:{Lore:['[{"text":"Lava Walker III","italic":false,"color":"gray"}]']}} 1

A datapack made by Kevcore25